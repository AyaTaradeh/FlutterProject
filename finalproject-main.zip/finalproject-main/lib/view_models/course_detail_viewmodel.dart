import 'package:projectfeeds/views/course_detail_page.dart';

class CourseDetailViewModel {
  final CourseDetailPage courseDetail;

  CourseDetailViewModel({required this.courseDetail});

  // Additional logic (if any) related to course details can go here
}

